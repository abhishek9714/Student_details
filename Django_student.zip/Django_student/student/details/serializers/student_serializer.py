from rest_framework import serializers
from ..models import school


class Author_details_serializers(serializers.ModelSerializer):
    class Meta:
        model = school
        fields = ('s_id', 'student_name', 'class_detail')
        depth = 2
