# -*- coding: utf-8 -*-
from django.conf.urls import url
from .views import student

urlpatterns = [
    url(regex=r'(?P<s_id_id>[^/]+)',
        view=student.details.as_view(), name='std_view'),
]
