from django.db.models import Q
from rest_framework.views import APIView
from rest_framework.response import Response
from ..models import School_name
from ..helpers.student_helpers import student_helper
import pdb


class details(APIView):

    def get(self, request, s_id_id=None, *args, **kwargs):
        # get author_id
        try:
            pdb.set_trace()
            student_id = School_name.objects.filter(
                Q(s_id_id=s_id_id)).first().s_id_id
            student = student_helper()
            jview = student.get_active_students(student_id)
        except:
            return Response(data={'status': 'invalid student_id'})
        return Response(data={'status': 'SUCCESS', 'authors': jview})
