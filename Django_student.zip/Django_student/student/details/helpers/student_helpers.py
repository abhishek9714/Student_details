from copy import deepcopy
from django.db.models import Q
from rest_framework.response import Response
from ..models import School_name
from ..serializers import Author_details_serializers
import pdb


class student_helper(object):

    def get_active_students(self, student_id):
        pdb.set_trace()
        #print('student_id', student_id)
        student_get = School_name.objects.filter(s_id=student_id)
        #print(student_get.values().all())
        student_data = Author_details_serializers(student_id, many=True).data
        pass
