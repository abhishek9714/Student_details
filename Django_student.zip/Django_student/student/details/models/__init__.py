from .student_details import student_detail
from .school import School_name
