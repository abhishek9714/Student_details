from django.db import models
from django.db.models.signals import post_delete, post_save
from django.dispatch import receiver
from django.utils import timezone


class student_detail(models.Model):
    student_id = models.CharField(max_length=32, primary_key=True, db_index=True,null=False)
    student_name = models.CharField(max_length=512, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'student_details'
        #unique_together = ('student_id','s_name')
