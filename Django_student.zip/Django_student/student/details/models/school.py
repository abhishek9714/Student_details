from django.db import models
from django.db.models.signals import post_delete, post_save
from django.dispatch import receiver
from django.utils import timezone
from django.contrib.postgres.fields import ArrayField


class School_name(models.Model):
    s_id = models.ForeignKey('Student_detail', unique=True, null=False, default="", editable=False,
                             to_field='student_id', on_delete=models.CASCADE)
    school_names = models.CharField(max_length=512, blank=True, primary_key=True)
    class_detail = ArrayField(models.CharField(max_length=200), blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'school'
